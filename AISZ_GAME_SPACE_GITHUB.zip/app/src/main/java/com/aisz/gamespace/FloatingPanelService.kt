package com.aisz.gamespace

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color as AColor

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var handle: View? = null
    private var panel: View? = null
    private var expanded = false
    private var startY = 0
    private var initialY = 0

    private fun params(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL; x = 0 }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val h = TextView(this).apply {
            text = "━\n━"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(AColor.rgb(121, 172, 218))
            setBackgroundColor(AColor.rgb(28, 38, 53))
            setPadding(10, 24, 10, 24)
            setOnClickListener { togglePanel() }
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { startY = event.rawY.toInt(); initialY = (layoutParamsOrNull(handle)?.y ?: 0); true }
                    MotionEvent.ACTION_MOVE -> {
                        val lp = layoutParamsOrNull(handle)
                        if (lp != null) {
                            lp.y = initialY + event.rawY.toInt() - startY
                            try { wm.updateViewLayout(handle, lp) } catch (_: Exception) {}
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> { if (kotlin.math.abs(event.rawY.toInt() - startY) < 12) togglePanel(); true }
                    else -> true
                }
            }
        }
        handle = h
        wm.addView(h, params(dp(34), dp(74)))
    }

    private fun layoutParamsOrNull(v: View?): WindowManager.LayoutParams? =
        try { v?.layoutParams as? WindowManager.LayoutParams } catch (_: Exception) { null }

    private fun togglePanel() {
        if (expanded) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            panel = null
            expanded = false
        } else {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(14), dp(14), dp(14))
                setBackgroundColor(AColor.rgb(23, 30, 43))
            }
            fun item(label: String) {
                box.addView(TextView(this).apply {
                    text = label
                    textSize = 14f
                    setTextColor(AColor.rgb(232, 237, 245))
                    setPadding(dp(8), dp(12), dp(8), dp(12))
                })
            }
            item("AISZ QUICK PANEL")
            item("Game Booster  •  Ready")
            item("FPS Monitor  •  N/A")
            item("Battery temperature")
            item("Touch Tester")
            item("Open AISZ Settings")
            panel = box
            val p = params(dp(220), WindowManager.LayoutParams.WRAP_CONTENT).apply {
                flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                x = dp(42)
            }
            wm.addView(box, p)
            expanded = true
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
