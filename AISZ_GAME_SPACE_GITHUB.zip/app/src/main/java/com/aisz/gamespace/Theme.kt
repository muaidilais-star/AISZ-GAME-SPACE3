package com.aisz.gamespace

import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF10141D)
val Surface = Color(0xFF171E2B)
val Panel = Color(0xFF1C2635)
val Panel2 = Color(0xFF222E40)
val Accent = Color(0xFF528FCB)
val AccentLight = Color(0xFF79ACDA)
val TextMain = Color(0xFFE8EDF5)
val TextMuted = Color(0xFF9BA9BA)
val Stroke = Color(0xFF303D50)
