package com.aisz.gamespace

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

data class GameApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

fun loadLaunchableApps(context: Context): List<GameApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val results = if (Build.VERSION.SDK_INT >= 33) {
        pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
    } else {
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(intent, 0)
    }
    return results.mapNotNull { info ->
        val activity = info.activityInfo ?: return@mapNotNull null
        if (activity.packageName == context.packageName) return@mapNotNull null
        GameApp(
            label = info.loadLabel(pm).toString(),
            packageName = activity.packageName,
            icon = info.loadIcon(pm)
        )
    }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
}
