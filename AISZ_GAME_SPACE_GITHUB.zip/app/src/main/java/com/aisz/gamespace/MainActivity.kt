package com.aisz.gamespace

import android.content.*
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.TextView
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AiszApp() }
    }
}

@Composable
fun AiszApp() {
    val context = LocalContext.current
    var page by remember { mutableStateOf(0) }
    var temp by remember { mutableStateOf<Float?>(null) }
    var favorite by remember { mutableStateOf(setOf<String>()) }
    var query by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf(emptyList<GameApp>()) }
    var floatingEnabled by remember { mutableStateOf(false) }
    var animations by remember { mutableStateOf(true) }

    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                val raw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
                temp = if (raw >= 0) raw / 10f else null
            }
        }
        context.registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        onDispose { try { context.unregisterReceiver(receiver) } catch (_: Exception) {} }
    }
    LaunchedEffect(Unit) { apps = loadLaunchableApps(context) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Surface, primary = Accent,
        onBackground = TextMain, onSurface = TextMain
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Surface, contentColor = TextMuted) {
                    val items = listOf("Home", "Games", "Tools", "Settings")
                    val icons = listOf(Icons.Default.Home, Icons.Default.SportsEsports, Icons.Default.Build, Icons.Default.Settings)
                    items.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = page == index,
                            onClick = { page = index },
                            icon = { Icon(icons[index], null) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AccentLight, selectedTextColor = AccentLight,
                                indicatorColor = Panel2, unselectedIconColor = TextMuted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            AnimatedContent(page, modifier = Modifier.padding(padding), transitionSpec = {
                fadeIn() + slideInHorizontally { it / 12 } togetherWith fadeOut() + slideOutHorizontally { -it / 12 }
            }, label = "pages") { p ->
                when (p) {
                    0 -> HomePage(apps.size, temp, onStart = {
                        if (Settings.canDrawOverlays(context)) {
                            context.startService(Intent(context, FloatingPanelService::class.java))
                            floatingEnabled = true
                        } else {
                            context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                        }
                    })
                    1 -> GamesPage(apps, query, { query = it }, favorite, { name ->
                        favorite = if (name in favorite) favorite - name else favorite + name
                    })
                    2 -> ToolsPage()
                    else -> SettingsPage(
                        floatingEnabled, animations,
                        onFloating = {
                            if (Settings.canDrawOverlays(context)) {
                                context.startService(Intent(context, FloatingPanelService::class.java))
                                floatingEnabled = true
                            } else context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                        },
                        onStopFloating = {
                            context.stopService(Intent(context, FloatingPanelService::class.java))
                            floatingEnabled = false
                        },
                        onAnimations = { animations = it },
                        onSystemSettings = { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
                    )
                }
            }
        }
    }
}

@Composable
fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp), content = content)
}

@Composable
fun Header(subtitle: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("AISZ", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
            Text("GAME SPACE  /  $subtitle", color = TextMuted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        }
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Panel).border(1.dp, Stroke, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Settings, null, tint = AccentLight)
        }
    }
}

@Composable
fun PanelCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Panel).border(1.dp, Stroke, RoundedCornerShape(18.dp)).padding(16.dp), content = content)
}

@Composable
fun HomePage(gameCount: Int, temp: Float?, onStart: () -> Unit) {
    PageColumn {
        Header("CONTROL CENTER")
        Spacer(Modifier.height(22.dp))
        Text("GAMING CENTER", color = TextMuted, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(10.dp))
        PanelCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Ready for your next game?", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("$gameCount launchable apps detected", color = TextMuted, fontSize = 12.sp)
                }
                Icon(Icons.Default.SportsEsports, null, tint = AccentLight, modifier = Modifier.size(34.dp))
            }
            Spacer(Modifier.height(18.dp))
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                Icon(Icons.Default.Bolt, null)
                Spacer(Modifier.width(8.dp))
                Text("START GAMING", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("DEVICE MONITOR", color = TextMuted, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("FPS", "N/A", "Not available", Modifier.weight(1f))
                MetricCard("BATTERY TEMP", temp?.let { "%.1f°C".format(it) } ?: "N/A", "Battery sensor", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("RAM", "—", "System restricted", Modifier.weight(1f))
                MetricCard("BATTERY", "System", "See device settings", Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(18.dp))
        PanelCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.GridView, null, tint = AccentLight)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("QUICK ACCESS", fontWeight = FontWeight.Bold)
                    Text("Games, tools and performance controls", color = TextMuted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, detail: String, modifier: Modifier = Modifier) {
    PanelCard(modifier) {
        Text(title, color = TextMuted, fontSize = 10.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))
        Text(value, color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(detail, color = TextMuted, fontSize = 10.sp)
    }
}

@Composable
fun GamesPage(apps: List<GameApp>, query: String, onQuery: (String) -> Unit, favorites: Set<String>, onFavorite: (String) -> Unit) {
    val context = LocalContext.current
    PageColumn {
        Header("GAME LIBRARY")
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(query, onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search installed apps…", color = TextMuted) }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Stroke))
        Spacer(Modifier.height(14.dp))
        Text("${apps.count { it.label.contains(query, true) }} APPS FOUND", color = TextMuted, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(10.dp))
        apps.filter { it.label.contains(query, true) }.chunked(2).forEach { rowApps ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowApps.forEach { app ->
                    PanelCard(Modifier.weight(1f).clickable {
                        context.packageManager.getLaunchIntentForPackage(app.packageName)?.let { context.startActivity(it) }
                    }) {
                        AndroidView(factory = { android.widget.ImageView(it).apply { setImageDrawable(app.icon); scaleType = android.widget.ImageView.ScaleType.FIT_CENTER } }, modifier = Modifier.size(42.dp))
                        Spacer(Modifier.height(9.dp))
                        Text(app.label, fontWeight = FontWeight.SemiBold, maxLines = 1, fontSize = 13.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("OPEN GAME", color = AccentLight, fontSize = 9.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = { onFavorite(app.packageName) }, modifier = Modifier.size(28.dp)) {
                                Icon(if (app.packageName in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = AccentLight, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
                if (rowApps.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (apps.isEmpty()) Text("No launchable apps detected.", color = TextMuted)
    }
}

@Composable
fun ToolsPage() {
    var x by remember { mutableStateOf(0f) }
    var y by remember { mutableStateOf(0f) }
    var points by remember { mutableStateOf(0) }
    PageColumn {
        Header("GAMING TOOLS")
        Spacer(Modifier.height(18.dp))
        PanelCard(Modifier.fillMaxWidth()) {
            Text("TOUCH TESTER", color = AccentLight, fontSize = 11.sp, letterSpacing = 1.5.sp)
            Text("Touch the area to test touch response and multi-touch.", color = TextMuted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.fillMaxWidth().height(270.dp).clip(RoundedCornerShape(14.dp))
                    .background(Surface).border(1.dp, Stroke, RoundedCornerShape(14.dp))
                    .pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent()
                                points = event.changes.count { it.pressed }
                                event.changes.firstOrNull { it.pressed }?.let {
                                    x = it.position.x
                                    y = it.position.y
                                }
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.TouchApp, null, tint = AccentLight, modifier = Modifier.size(34.dp))
                    Text("TOUCH AREA", color = TextMuted, fontSize = 11.sp)
                }
                Box(Modifier.offset(x = (x / 3).dp, y = (y / 3).dp).size(13.dp).clip(CircleShape).background(AccentLight.copy(alpha = .8f)))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("X: ${x.toInt()}  Y: ${y.toInt()}", color = TextMuted, fontSize = 12.sp)
                Text("Fingers: $points", color = AccentLight, fontSize = 12.sp)
            }
            TextButton(onClick = { x = 0f; y = 0f; points = 0 }) { Text("RESET", color = AccentLight) }
        }
        Spacer(Modifier.height(12.dp))
        PanelCard(Modifier.fillMaxWidth()) {
            Text("FPS MONITOR", fontWeight = FontWeight.Bold)
            Text("N/A — Android does not expose reliable FPS data for other apps to ordinary applications.", color = TextMuted, fontSize = 12.sp)
        }
    }
}

@Composable
fun SettingsPage(floating: Boolean, animations: Boolean, onFloating: () -> Unit, onStopFloating: () -> Unit, onAnimations: (Boolean) -> Unit, onSystemSettings: () -> Unit) {
    PageColumn {
        Header("PREFERENCES")
        Spacer(Modifier.height(18.dp))
        Text("GENERAL", color = TextMuted, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(9.dp))
        PanelCard(Modifier.fillMaxWidth()) {
            SettingRow(Icons.Default.Tune, "Gaming preferences", "Configure your gaming environment")
            Divider(color = Stroke)
            SettingRow(Icons.Default.Palette, "Appearance", "Dark navy · Soft blue accent")
            Divider(color = Stroke)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Animation, null, tint = AccentLight)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Smooth animations", fontWeight = FontWeight.SemiBold)
                    Text("Lightweight page transitions", color = TextMuted, fontSize = 11.sp)
                }
                Switch(checked = animations, onCheckedChange = onAnimations, colors = SwitchDefaults.colors(checkedThumbColor = TextMain, checkedTrackColor = Accent))
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("FLOATING PANEL", color = TextMuted, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(9.dp))
        PanelCard(Modifier.fillMaxWidth()) {
            SettingRow(Icons.Default.DragIndicator, "Edge handle", "Right side · draggable")
            Text("Overlay permission is required by Android.", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            Button(onClick = if (floating) onStopFloating else onFloating, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = if (floating) Panel2 else Accent)) {
                Text(if (floating) "STOP FLOATING PANEL" else "ENABLE FLOATING PANEL")
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("SYSTEM", color = TextMuted, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(9.dp))
        PanelCard(Modifier.fillMaxWidth()) {
            SettingRow(Icons.Default.SettingsSuggest, "Android settings", "Open device settings")
            Button(onClick = onSystemSettings, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Panel2)) {
                Text("OPEN SYSTEM SETTINGS")
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("AISZ GAME SPACE  •  VERSION 1.0", color = TextMuted, fontSize = 10.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Panel2), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = AccentLight)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(detail, color = TextMuted, fontSize = 11.sp)
        }
    }
}
